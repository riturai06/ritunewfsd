package com.cts.ritu.rest;

public class Product {
	
	private String prodName;
	private int prodId;
	private int prodQuantity;
	private float prodPrice;
	
	public Product() {
		
	}

	public Product(String prodName, int prodId, int prodQuantity, float prodPrice) {
		
		this.prodName = prodName;
		this.prodId = prodId;
		this.prodQuantity = prodQuantity;
		this.prodPrice = prodPrice;
	}
	

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public int getProdId() {
		return prodId;
	}

	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public int getProdQuantity() {
		return prodQuantity;
	}

	public void setProdQuantity(int prodQuantity) {
		this.prodQuantity = prodQuantity;
	}

	public float getProdPrice() {
		return prodPrice;
	}

	public void setProdPrice(float prodPrice) {
		this.prodPrice = prodPrice;
	}
	
	
	
	

}
