package com.cts.ritu.rest;

import java.util.*;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestDemo {
	
	List<Product> newList = new ArrayList<>();
	Map<Integer,Product> newMap = new HashMap<>();
	
	public RestDemo() {
		//ListObjects
		newList.add(new Product("DVD", 500, 6, 4354.20f));
		newList.add(new Product("Computer", 803, 5, 859.8f));
		newList.add(new Product("TV", 504, 6, 4584.3f));
		newList.add(new Product("CD Player", 505, 2, 5689.14f));
		//MapObjects
		newMap.put(1001, new Product("DVD", 500, 6, 4354.20f));
		newMap.put(1002, new Product("Computer", 803, 5, 859.8f));
		newMap.put(1003, new Product("TV", 504, 6, 4584.3f));
		newMap.put(1004, new Product("CD Player", 505, 2, 5689.14f));
	}
	
	
	@RequestMapping("/data")
	public String getIndex() {
		return "simple data";
	}
	
	
	@RequestMapping("/jsondata")
	public String getString() {
		return "{\"payroll\":\"success\",\"data\":\"json\"}";
	}
	
	
	@RequestMapping("/jsonProdList")
	public List<Product> getProductList() {
		return newList;
	}
	
	
	@RequestMapping("/jsonProdMap")
	public Map<Integer,Product>getProdMap() {
		return newMap;
	}
	
	//If u want to check through URL, use GET
	@RequestMapping(value="/getbyid/{pid}", method=RequestMethod.POST) 
	public Product getById(@PathVariable("pid") int id) {
		return newMap.get(id);
	}

}
