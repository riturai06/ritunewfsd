package com.cts.hibernatedemo2;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.model.ProductData;

public class HIbernateDemo2 {

	public static void main(String[] args) {
		Configuration configuration = new Configuration().configure();
		SessionFactory sf = configuration.buildSessionFactory();
		Session session = sf.openSession();
		/*String hqlQuery = "FROM ProductData";
		Query q =  session.createQuery(hqlQuery);
		List result = q.list();
		System.out.println(result);*/
		
		/*String hql = "FROM ProductData pd where pd.prodId=?";
		Query q = session.createQuery(hql);
		q.setParameter(0,1008);
		List result = q.list();
		System.out.println(result);*/
		
		/*Query query = session.createQuery(
				 "From ProductData pd where pd.prodId = :id "); query.setParameter("id", 1009);
				 List<ProductData> list=query.list(); System.out.println(list);*/
		
		/*ProductData productData = new ProductData(); 
		productData.setProdId(1008); 
		String hql = "FROM ProductData pd where pd.prodId = :prodId"; 
		List result = session.createQuery(hql).setProperties(productData).list();
		System.out.println(result);*/
		
		
		/*String qry="select pd.prodprice FROM ProductData pd"; 
		Query q=session.createQuery(qry); 
		List<ProductData> pd=q.list();//will not throw class cast exception because pd.prodPrice value is being set into ProductData object(pd). 
		System.out.println(pd);*/
		
		Query q=session.createSQLQuery("select * from Product");
		//native qry execution
		System.out.println(q.list());
		
		
		/*how to change this object into values*/
		//Hibernate: select * from Product
		//[[Ljava.lang.Object;@26ceffa8, [Ljava.lang.Object;@600b90df]
		
		Query q1=session.getNamedQuery("getquery");
		System.out.println(q1.list());
		
		/*Query q1=session.getNamedQuery("getprice");
		System.out.println(q1.list());
		
		Query q2=session.getNamedQuery("selectall");
		System.out.println(q.list());
		
		Query q3=session.getNamedQuery("selectprice");
		System.out.println(q1.list());*/
		
		q.setFirstResult(2);
		q.setFetchSize(2);
		
		session.close();
	}

}
